from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua_chave_secreta'  # Substitua por uma chave secreta real
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///clientes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Modelo de Cliente
class Cliente(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    numero = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    nome = db.Column(db.String(100), nullable=False)
    servico = db.Column(db.String(100), nullable=False)
    data_compra = db.Column(db.Date, nullable=False)

    def __repr__(self):
        return f'<Cliente {self.nome}>'

# Rota para a Página Inicial
@app.route('/')
def index():
    hoje = datetime.today().date()

    # Período da Semana Atual
    semana_inicio = hoje - timedelta(days=hoje.weekday())  # Início da semana (segunda-feira)
    semana_fim = semana_inicio + timedelta(days=6)        # Fim da semana (domingo)

    # Período do Mês Atual
    mes_inicio = hoje.replace(day=1)
    mes_fim = (mes_inicio + relativedelta(months=1)) - timedelta(days=1)

    # Período do Mês Passado
    mes_passado_inicio = (mes_inicio - relativedelta(months=1))
    mes_passado_fim = mes_inicio - timedelta(days=1)

    # Clientes para Renovar Hoje (1 mês após a compra)
    um_mes_atras = hoje - relativedelta(months=1)
    clientes_hoje = Cliente.query.filter(
        Cliente.data_compra == um_mes_atras
    ).all()

    # Clientes da Semana
    clientes_semana = Cliente.query.filter(
        Cliente.data_compra >= semana_inicio,
        Cliente.data_compra <= semana_fim
    ).all()

    # Clientes do Mês Atual
    clientes_mes_atual = Cliente.query.filter(
        Cliente.data_compra >= mes_inicio,
        Cliente.data_compra <= mes_fim
    ).all()

    # Clientes do Mês Passado
    clientes_mes_passado = Cliente.query.filter(
        Cliente.data_compra >= mes_passado_inicio,
        Cliente.data_compra <= mes_passado_fim
    ).all()

    # Totais
    total_semana = len(clientes_semana)
    total_mes_atual = len(clientes_mes_atual)
    total_mes_passado = len(clientes_mes_passado)

    # Total Geral
    total_geral = total_semana + total_mes_atual + total_mes_passado

    return render_template('index.html',
                           clientes_hoje=clientes_hoje,
                           clientes_semana=clientes_semana,
                           clientes_mes_atual=clientes_mes_atual,
                           clientes_mes_passado=clientes_mes_passado,
                           total_semana=total_semana,
                           total_mes_atual=total_mes_atual,
                           total_mes_passado=total_mes_passado,
                           total_geral=total_geral,
                           hoje=hoje,
                           semana_inicio=semana_inicio,
                           semana_fim=semana_fim,
                           mes_inicio=mes_inicio,
                           mes_fim=mes_fim,
                           mes_passado_inicio=mes_passado_inicio,
                           mes_passado_fim=mes_passado_fim)

# Rota para Adicionar Cliente
@app.route('/adicionar', methods=['GET', 'POST'])
def adicionar():
    if request.method == 'POST':
        numero = request.form['numero']
        email_cliente = request.form['email']
        nome = request.form['nome']
        servico = request.form['servico']
        data_compra_str = request.form['data_compra']
        try:
            data_compra = datetime.strptime(data_compra_str, '%Y-%m-%d').date()
        except ValueError:
            flash("Data inválida. Use o formato AAAA-MM-DD.", "error")
            return redirect(url_for('adicionar'))

        novo_cliente = Cliente(numero=numero, email=email_cliente, nome=nome, servico=servico, data_compra=data_compra)
        db.session.add(novo_cliente)
        db.session.commit()
        flash("Cliente adicionado com sucesso!", "success")
        return redirect(url_for('index'))
    return render_template('adicionar.html')

# Rota para Editar Cliente
@app.route('/editar/<int:cliente_id>', methods=['GET', 'POST'])
def editar(cliente_id):
    cliente = Cliente.query.get_or_404(cliente_id)
    if request.method == 'POST':
        cliente.numero = request.form['numero']
        cliente.email = request.form['email']
        cliente.nome = request.form['nome']
        cliente.servico = request.form['servico']
        data_compra_str = request.form['data_compra']
        try:
            cliente.data_compra = datetime.strptime(data_compra_str, '%Y-%m-%d').date()
        except ValueError:
            flash("Data inválida. Use o formato AAAA-MM-DD.", "error")
            return redirect(url_for('editar', cliente_id=cliente_id))
        
        db.session.commit()
        flash("Cliente atualizado com sucesso!", "success")
        return redirect(url_for('index'))
    return render_template('editar.html', cliente=cliente)

# Rota para Excluir Cliente
@app.route('/deletar/<int:cliente_id>', methods=['POST'])
def deletar(cliente_id):
    cliente = Cliente.query.get_or_404(cliente_id)
    db.session.delete(cliente)
    db.session.commit()
    flash("Cliente excluído com sucesso!", "success")
    return redirect(url_for('index'))

# Criação das Tabelas ao Iniciar a Aplicação
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Cria as tabelas no banco de dados
    app.run(debug=True)
